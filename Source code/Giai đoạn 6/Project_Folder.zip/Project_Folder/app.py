import streamlit as st
import networkx as nx
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import random
import community.community_louvain as community_louvain
from pyvis.network import Network
import streamlit.components.v1 as components
import plotly.graph_objects as go

# --- CẤU HÌNH TRANG ---
st.set_page_config(layout="wide", page_title="SNA Facebook Dashboard")

# --- 1. DATA LOADING & CACHING (Đã xử lý tên cột) ---
@st.cache_data
def load_data():
    # 1. Đọc dữ liệu Mạng lưới
    G = nx.read_edgelist("facebook_combined_cleaned.txt", create_using=nx.Graph(), nodetype=str)
    
    # 2. Đọc dữ liệu Role Table
    roles = pd.read_csv("role_table.csv")
    
    # --- XỬ LÝ TÊN CỘT (QUAN TRỌNG) ---
    # Chuẩn hóa tên cột: Xóa khoảng trắng thừa (nếu có)
    roles.columns = roles.columns.str.strip()
    
    # Đổi tên cột 'Betweenness' -> 'BetweennessCentrality' để khớp với code
    # Cột 'DegreeCentrality' của cậu đã đúng nên giữ nguyên
    rename_map = {
        'Betweenness': 'BetweennessCentrality',
        'betweenness': 'BetweennessCentrality',
        # Phòng hờ nếu file sau này có thay đổi
        'Degree': 'DegreeCentrality',
        'degree': 'DegreeCentrality'
    }
    roles.rename(columns=rename_map, inplace=True)
    
    # Ép kiểu NodeID về string để khớp với NetworkX
    roles['NodeID'] = roles['NodeID'].astype(str)
    
    return G, roles

# --- SỬA LỖI CACHING ---
@st.cache_data
def get_partition(_G):
    # Thêm dấu _ trước G để Streamlit không hash biến này
    return community_louvain.best_partition(_G)

# Tải dữ liệu và xử lý ngoại lệ
try:
    G_clean, df_roles = load_data()
    partition = get_partition(G_clean)
    num_communities = len(set(partition.values()))
except FileNotFoundError:
    st.error("❌ Lỗi: Không tìm thấy file dữ liệu!")
    st.warning("👉 Hãy đảm bảo 'facebook_combined_cleaned.txt' và 'role_table.csv' nằm cùng thư mục.")
    st.stop()
except KeyError as e:
    st.error(f"❌ Lỗi tên cột trong CSV: Không tìm thấy cột {e}")
    st.write("Các cột hiện có:", pd.read_csv("role_table.csv").columns.tolist())
    st.stop()

# --- 2. HÀM MÔ PHỎNG SIR ---
def run_simulation_engine(G, seeds, beta=0.05, gamma=0.1, max_steps=50):
    status = {node: 0 for node in G.nodes()} # 0: S, 1: I, 2: R
    for seed in seeds:
        status[seed] = 1 # Infected
    
    history = []
    for t in range(max_steps):
        count_I = sum(1 for n in status.values() if n == 1)
        count_R = sum(1 for n in status.values() if n == 2)
        history.append(count_I + count_R)
        
        if count_I == 0:
            history.extend([history[-1]] * (max_steps - t - 1))
            break
            
        new_infected = []
        new_recovered = []
        infected_nodes = [n for n, s in status.items() if s == 1]
        
        for u in infected_nodes:
            for v in G.neighbors(u):
                if status[v] == 0:
                    if random.random() < beta:
                        new_infected.append(v)
            if random.random() < gamma:
                new_recovered.append(u)
                
        for n in new_infected: status[n] = 1
        for n in new_recovered: status[n] = 2
            
    return history

# --- 3. GIAO DIỆN DASHBOARD ---

st.title("🕸️ Phân tích & Tối ưu hóa Lan truyền trên Mạng xã hội Facebook")
st.markdown("---")

# Tạo 3 Tabs
tab1, tab2, tab3 = st.tabs(["📊 Network Anatomy", "🌍 Community Structure", "⚔️ The Battle (Simulation)"])

# === TAB 1: NETWORK ANATOMY ===
with tab1:
    st.header("1. Giải phẫu Mạng lưới & Vai trò Nút")
    
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Số lượng Nút (Nodes)", f"{G_clean.number_of_nodes():,}")
    col2.metric("Số lượng Cạnh (Edges)", f"{G_clean.number_of_edges():,}")
    col3.metric("Số lượng Cộng đồng", num_communities)
    col4.metric("Mật độ mạng", f"{nx.density(G_clean):.4f}")
    
    st.subheader("🏆 Role Table: Top Key Players")
    
    # Dropdown chọn tiêu chí sắp xếp
    # Lưu ý: Code dưới dùng tên chuẩn 'BetweennessCentrality' sau khi đã rename
    sort_by = st.selectbox("Sắp xếp theo:", ["DegreeCentrality", "BetweennessCentrality", "PageRank"])
    
    # Kiểm tra xem cột PageRank có tồn tại không, nếu không thì ẩn đi để tránh lỗi
    if sort_by not in df_roles.columns:
        st.warning(f"File CSV của bạn chưa có cột {sort_by}, hãy chọn cột khác.")
    else:
        top_users = df_roles.sort_values(by=sort_by, ascending=False).head(20)
        st.dataframe(top_users.style.background_gradient(cmap="Blues"), use_container_width=True)
    
    st.info("💡 **Insight:** Hubs (Degree cao) thường là người nổi tiếng. Bridges (Betweenness cao) là người kết nối các nhóm.")

# === TAB 2: COMMUNITY STRUCTURE ===
with tab2:
    st.header("2. Cấu trúc Cộng đồng (Interactive)")
    limit_nodes = st.slider("Số lượng nút hiển thị (để tránh lag)", 100, 1000, 300)
    
    if st.button("Tạo Biểu đồ Tương tác"):
        with st.spinner("Đang vẽ đồ thị..."):
            sub_nodes = list(G_clean.nodes())[:limit_nodes]
            G_sub = G_clean.subgraph(sub_nodes)
            
            net = Network(height="600px", width="100%", bgcolor="#222222", font_color="white")
            
            for node in G_sub.nodes():
                comm_id = partition[node]
                net.add_node(node, title=f"Node: {node} | Group: {comm_id}", group=comm_id)
            
            for edge in G_sub.edges():
                net.add_edge(edge[0], edge[1], alpha=0.5)
                
            net.force_atlas_2based()
            
            path = "community_graph.html"
            net.save_graph(path)
            
            # Đọc file utf-8 an toàn
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    html_content = f.read()
                components.html(html_content, height=620)
            except:
                st.error("Lỗi hiển thị HTML.")

# === TAB 3: THE BATTLE (SIMULATION) ===
with tab3:
    st.header("3. The Battle: Cuộc chiến Chiến lược Seeding 🚀")
    
    col_input, col_chart = st.columns([1, 3])
    
    with col_input:
        st.subheader("⚙️ Thiết lập")
        k_seeds = st.slider("Số lượng Hạt giống", 5, 50, 10)
        beta = st.number_input("Tỷ lệ lây nhiễm (Beta)", 0.01, 1.0, 0.05)
        gamma = st.number_input("Tỷ lệ hồi phục (Gamma)", 0.01, 1.0, 0.1)
        n_trials = st.slider("Số lần chạy (Monte Carlo)", 10, 100, 20)
        
        btn_run = st.button("🔥 RUN SIMULATION", type="primary")

    with col_chart:
        if btn_run:
            with st.spinner(f"Đang chạy mô phỏng..."):
                # Chọn Seeds dựa trên tên cột chuẩn
                try:
                    seeds_hubs = df_roles.sort_values('DegreeCentrality', ascending=False).head(k_seeds)['NodeID'].tolist()
                    seeds_bridges = df_roles.sort_values('BetweennessCentrality', ascending=False).head(k_seeds)['NodeID'].tolist()
                except KeyError as e:
                    st.error(f"Lỗi: Không tìm thấy cột {e} để chạy mô phỏng.")
                    st.stop()

                seeds_random = random.sample(list(G_clean.nodes()), min(k_seeds, len(G_clean.nodes())))
                
                def run_monte_carlo(seeds):
                    results = []
                    for _ in range(n_trials):
                        res = run_simulation_engine(G_clean, seeds, beta, gamma, max_steps=50)
                        results.append(res)
                    return np.mean(results, axis=0)
                
                hist_hubs = run_monte_carlo(seeds_hubs)
                hist_bridges = run_monte_carlo(seeds_bridges)
                hist_random = run_monte_carlo(seeds_random)
                
                fig = go.Figure()
                steps = list(range(50))
                
                fig.add_trace(go.Scatter(x=steps, y=hist_hubs, mode='lines', name='HUBS (Degree)', line=dict(color='red', width=3)))
                fig.add_trace(go.Scatter(x=steps, y=hist_bridges, mode='lines', name='BRIDGES (Betweenness)', line=dict(color='blue', width=3, dash='dash')))
                fig.add_trace(go.Scatter(x=steps, y=hist_random, mode='lines', name='RANDOM', line=dict(color='gray', width=2, dash='dot')))
                
                fig.update_layout(title="So sánh Hiệu quả Lan truyền", height=500, template="plotly_white")
                st.plotly_chart(fig, use_container_width=True)
                
                final_hubs, final_bridges = hist_hubs[-1], hist_bridges[-1]
                st.success(f"📊 Kết quả: Bridges ({int(final_bridges)}) vs Hubs ({int(final_hubs)})")